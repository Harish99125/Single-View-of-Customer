package com.example.svclp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SingleViewofCustomerApplicationTests {

	@Test
	void contextLoads() {
	}

}
